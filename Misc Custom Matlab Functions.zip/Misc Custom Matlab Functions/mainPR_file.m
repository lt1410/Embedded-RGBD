clc
clear
% chair models = 2299  and it is called 3001627
% table models = 2300  and it is called 4379243
% lamp models = 2295  and it is called 3636649
% total = 6894
[chair_r,table_r,lamp_r] = GetFileListToMat();
chair_r(124,:) = []; % Removed because python code segfaulted at this value
% Basic Variables

correctNum_chair = 3001627;
%numOfChair = nnz(chair_r==correctNum_chair)/size(chair_r,1);
numOfChair = 2299;
correctNum_table = 4379243;
%numOfTable = nnz(chair_r==correctNum_table)/size(table_r,1);
numOfTable = 2300;
correctNum_lamp = 3636649;
%numOfLamp = nnz(chair_r==correctNum_lamp)/size(lamp_r,1);
numOfLamp = 2295;

%% Pick Best n
n = 50; % CHANGE THIS TO CUSTOM NUMBER
% FOR CHAIR
for i = 1:size(chair_r,1)
    a(i,:) = find(chair_r(i,:)==3001627);
end
aa = sum(a,2);

[sort_a,idx] = sort(aa,'ascend');
picked = idx(1:n);
chair_r = chair_r(picked,:);
clear a aa sort_a idx picked;

% FOR TABLE
for i = 1:size(table_r,1)
    a(i,:) = find(table_r(i,:)==4379243);
end
aa = sum(a,2);

[sort_a,idx] = sort(aa,'ascend');
picked = idx(1:n);
table_r = table_r(picked,:);
clear a aa sort_a idx picked;

% FOR LAMP
for i = 1:size(lamp_r,1)
    a(i,:) = find(lamp_r(i,:)==3636649);
end
aa = sum(a,2);

[sort_a,idx] = sort(aa,'ascend');
picked = idx(1:n);
lamp_r = lamp_r(picked,:);
clear a aa sort_a idx picked;

%%
AvgPrecision1 = 0;
AvgPrecision2 = 0;
AvgPrecision3 = 0;

% Chair PR
for i = 1:size(chair_r,1)
    iter = 0;
    
    for j = 1:size(chair_r,2)
        if chair_r(i,j) == correctNum_chair
            iter = iter+1;
            
        end
        Precision1(i,j) = iter/j;
        Recall1(i,j) = iter/numOfChair;
    end
   
end


% Table PR
for i = 1:size(table_r,1)
    iter = 0;
    
    for j = 1:size(table_r,2)
        if table_r(i,j) == correctNum_table
            iter = iter+1;
            
        end
        Precision2(i,j) = iter/j;
        Recall2(i,j) = iter/numOfTable;
    end
    
end

% Lamp PR
for i = 1:size(lamp_r,1)
    iter = 0;
    
    for j = 1:size(lamp_r,2)
        if lamp_r(i,j) == correctNum_lamp
            iter = iter+1;
            
        end
        Precision3(i,j) = iter/j;
        Recall3(i,j) = iter/numOfLamp;
    end
   
end
Precision = vertcat(Precision1,Precision2,Precision3);
Recall = vertcat(Recall1,Recall2,Recall3);

meanPR = mean(Precision,1);
meanR = mean(Recall,1);
pr = [meanPR' meanR'];
prIndex = 1;
prInterpolated_temp = ones(11,2);
for m = 0:0.1:1 % Calculate interpolated precision for different recall levels.
    value = max(pr((pr(:,2)<=1) & (pr(:,2)>=m),1));
    prInterpolated_temp(prIndex,1) = value;
    prInterpolated_temp(prIndex,2) = m;
    prIndex = prIndex+1;
end

%plot(prInterpolated_temp(:,2),prInterpolated_temp(:,1),'b')

MAP2 = mean(meanPR);

plot(prInterpolated_temp(:,2),prInterpolated_temp(:,1));
    axis([0,1,0,1]);
    title('Interpolated P-R Curve Shape Retrieval from Depth Image');
    xlabel('Recall');
    ylabel('Precision');
    grid on;
    dim = [.66 .6 .3 .3];
    text = strcat({'MAP is : '},num2str(MAP2));
    annotation('textbox',dim,'String',text,'FontSize',15,'FitBoxToText','on','BackgroundColor','w');
    
