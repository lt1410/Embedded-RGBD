load('nyu_depth_v2_labeled.mat');
ID = find(strcmpi(names,'lamp')==1);
n = size(instances,3);
path = '/Users/EmokeWynterheart/Dropbox/NYU Course Material/Spring 2016/Research Assistantship/Code & Data/LampDepths/';
hpcpath = '/scratch/lt1410/JointEmbeding/JointEmbeding/data/image_embedding/depth_images3/';
count = 1;
for i = 1:n
    depth = zeros(size(depths(:,:,i)));
    %image = zeros(size(images(:,:,:,i)));
    %currentImage = images(:,:,:,i);
    currentDepth = depths(:,:,i);
    currentLabel = labels(:,:,i);
    IDInLabel = find(currentLabel == ID);
    if(~isempty(IDInLabel))
        depth(IDInLabel) = currentDepth(IDInLabel);
        %image(chairInInstance,:) = currentImage(chairInInstance,:);
        depthImage = mat2gray(depth, [min(min(depth)) max(max(depth))]);
        %save(strcat(path,num2str(i),'.png'),'chairImage');
        depthImage = imresize(depthImage,[277 277]);
        imgRGB = cat(3, depthImage, depthImage, depthImage);
        imwrite(imgRGB,strcat(path,num2str(i),'.png'));
        count = count+1;
    end
end
filelist = dir(strcat(path,'*.png'));
fname = {filelist.name}';
fname = strcat(hpcpath,fname);
fid = fopen('depth_filelist3.txt','w');
fprintf(fid,'%s\n',fname{:});
fclose(fid)
fid = fopen('depth_imageid2shapeid3.txt','w');
for i = 1:count
    fprintf(fid,'%d\n',i);
end
fclose(fid)