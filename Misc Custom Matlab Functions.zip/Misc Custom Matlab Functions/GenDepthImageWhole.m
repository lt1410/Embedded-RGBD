fid = fopen('shape_list_03001627.txt');
tline = fgetl(fid);
%path2 = '/scratch/lt1410/JointEmbeding/JointEmbeding/data/image_embedding/depth_images/';
%path = '/scratch/lt1410/JointEmbeding/JointEmbeding/data/image_embedding/syn_images_bkg_overlaid';
path2 = './ChairDepths/*.png';
path = './';
while ischar(tline)
    shape_property = strsplit(tline, ' ');
    filePath = fullfile(path,shape_property{1}, shape_property{2});
    mkdir(filePath);
    flist=dir(path2);
    if(flist(1).name(1) == '.' && flist(2).name(1) == '.')
        flist(1) = [];
        flist(1) = [];
    end
    p = randperm(size(flist,1),50)';
    for i=1:size(p,1)
        path3 = strcat(path2(1:end-5),flist(p(i)).name);
        copyfile(path3,filePath);
    end
    tline = fgetl(fid);
end