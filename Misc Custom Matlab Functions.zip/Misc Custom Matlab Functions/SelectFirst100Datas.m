addpath('../');

path = './03001627/';
flist = dir(path);
k = 1;

if(flist(1).name(1) == '.' && flist(2).name(1) == '.')
    flist(1) = [];
    flist(1) = [];
end
p = randperm(size(flist,1),size(flist,1)-2300)';
for i = 1:length(p)
    rmdir(strcat(path,flist(p(i)).name));
end

path = './03636649/';
flist = dir(path);
k = 1;
if(flist(1).name(1) == '.' && flist(2).name(1) == '.')
    flist(1) = [];
    flist(1) = [];
end
p = randperm(size(flist,1),size(flist,1)-2300)';
for i = 1:length(p)
    rmdir(strcat(path,flist(p(i)).name));
end

path = './04379243/';
flist = dir(path);
k = 1;
if(flist(1).name(1) == '.' && flist(2).name(1) == '.')
    flist(1) = [];
    flist(1) = [];
end
p = randperm(size(flist,1),size(flist,1)-2300)';
for i = 1:length(p)
    rmdir(strcat(path,flist(p(i)).name));
end