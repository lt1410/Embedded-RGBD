imgchairList = dir('./ChairDepths/*.png');
str = 'python image_based_shape_retrieval.py --image /scratch/lt1410/JointEmbeding/JointEmbeding/data/image_embedding/depth_images/REPLACEME  --type chair --caffemodel ./depth.caffemodel --prototxt ./depth.prototxt';
fid = fopen('./chair.txt','w');
for i = 1:length(imgchairList)
    str1 = strrep(str,'REPLACEME',imgchairList(i).name);    
    fprintf(fid, strcat(str1,'\n'));
end
fclose(fid);

imglampList = dir('./LampDepths/*.png');
str = 'python image_based_shape_retrieval.py --image /scratch/lt1410/JointEmbeding/JointEmbeding/data/image_embedding/depth_images3/REPLACEME  --type lamp --caffemodel ./depth.caffemodel --prototxt ./depth.prototxt';
fid = fopen('./Lamp.txt','w');
for i = 1:length(imglampList)
    str1 = strrep(str,'REPLACEME',imglampList(i).name);    
    fprintf(fid, strcat(str1,'\n'));
end
fclose(fid);

imgtableList = dir('./TableDepths/*.png');
str = 'python image_based_shape_retrieval.py --image /scratch/lt1410/JointEmbeding/JointEmbeding/data/image_embedding/depth_images2/REPLACEME  --type table --caffemodel ./depth.caffemodel --prototxt ./depth.prototxt';
fid = fopen('./table.txt','w');
for i = 1:length(imgtableList)
    str1 = strrep(str,'REPLACEME',imgtableList(i).name);    
    fprintf(fid, strcat(str1,'\n'));
end
fclose(fid);