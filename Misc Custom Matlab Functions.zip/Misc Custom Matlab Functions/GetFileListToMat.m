function [chair_r,table_r,lamp_r] = GetFileListToMat()
addpath(genpath('../'))
% chair models = 2299  and it is called 3001627
% table models = 2300  and it is called 4379243
% lamp models = 2295  and it is called 3636649
% total = 6894
chairlist = dir('./TextFile/chair/*.txt');
lamplist = dir('./TextFile/lamp/*.txt');
tablelist = dir('./TextFile/table/*.txt');

for i = 1:length(chairlist)
   chair_r(i,:) = csvread(chairlist(i).name);  
end
chair_r(:,1) = [];

for i = 1:length(tablelist)
   table_r(i,:) = csvread(tablelist(i).name);  
end
table_r(:,1) = [];

for i = 1:length(lamplist)
   lamp_r(i,:) = csvread(lamplist(i).name);  
end
lamp_r(:,1) = [];
